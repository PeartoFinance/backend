"""
Stocks API Routes with SQLAlchemy
- Quotes, search, profile, history, movers
"""
from flask import Blueprint, request, jsonify
from sqlalchemy import desc, asc
from models.base import db
from models.market import MarketData

stocks_bp = Blueprint('stocks', __name__)


@stocks_bp.route('/quotes', methods=['GET'])
def get_quotes():
    """Get real-time quotes for multiple symbols"""
    symbols_param = request.args.get('symbols', '')
    
    if not symbols_param:
        return jsonify({'error': 'symbols parameter required'}), 400
    
    symbols = [s.strip().upper() for s in symbols_param.split(',')]

    
    header_country = request.headers.get('X-User-Country')
    if header_country is None:
        # no header -> default to US only
        filter_condition = (MarketData.country_code == 'US')
    else:
        country = header_country.strip().upper()
        if country == 'GLOBAL':
            filter_condition = (MarketData.country_code == 'GLOBAL')
        else:
            filter_condition = (MarketData.country_code == country)

    prices = MarketData.query.filter(
        MarketData.symbol.in_(symbols),
        MarketData.asset_type == 'stock',
        filter_condition
    ).all()
    
    return jsonify([p.to_dict() for p in prices])


@stocks_bp.route('/search', methods=['GET'])
def search_stocks():
    """Search stocks by name or symbol"""
    query = request.args.get('q', '').strip()
    limit = min(int(request.args.get('limit', 10)), 50)
    
    if not query:
        return jsonify({'error': 'q parameter required'}), 400
    
    header_country = request.headers.get('X-User-Country')
    if header_country is None:
        filter_condition = (MarketData.country_code == 'US')
    else:
        country = header_country.strip().upper()
        filter_condition = (MarketData.country_code == 'GLOBAL') if country == 'GLOBAL' else (MarketData.country_code == country)

    stocks = MarketData.query.filter(
        db.or_(
            MarketData.symbol.ilike(f'%{query}%'),
            MarketData.name.ilike(f'%{query}%')
        ),
        MarketData.asset_type == 'stock',
        filter_condition
    ).limit(limit).all()
    
    return jsonify([{
        'symbol': s.symbol,
        'name': s.name,
        'exchange': s.exchange,
        'type': s.asset_type
    } for s in stocks])


@stocks_bp.route('/profile/<symbol>', methods=['GET'])
def get_profile(symbol):
    """Get basic stock profile from market data"""
    header_country = request.headers.get('X-User-Country')
    if header_country is None:
        filter_condition = (MarketData.country_code == 'US')
    else:
        country = header_country.strip().upper()
        filter_condition = (MarketData.country_code == 'GLOBAL') if country == 'GLOBAL' else (MarketData.country_code == country)

    stock = MarketData.query.filter(
        MarketData.symbol == symbol.upper(),
        MarketData.asset_type == 'stock',
        filter_condition
    ).first()
    
    if not stock:
        return jsonify({'error': 'Stock not found'}), 404
    
    return jsonify(stock.to_dict())


@stocks_bp.route('/movers', methods=['GET'])
def get_movers():
    """Get top gainers and losers"""
    mover_type = request.args.get('type', 'both')
    limit = min(int(request.args.get('limit', 10)), 50)
    
    result = {}
    
    header_country = request.headers.get('X-User-Country')
    if header_country is None:
        filter_condition = (MarketData.country_code == 'US')
    else:
        country = header_country.strip().upper()
        filter_condition = (MarketData.country_code == 'GLOBAL') if country == 'GLOBAL' else (MarketData.country_code == country)

    if mover_type in ('gainers', 'both'):
        gainers = MarketData.query.filter(
            MarketData.asset_type == 'stock',
            MarketData.change_percent > 0,
            filter_condition
        ).order_by(desc(MarketData.change_percent)).limit(limit).all()
        result['gainers'] = [g.to_dict() for g in gainers]
    
    if mover_type in ('losers', 'both'):
        losers = MarketData.query.filter(
            MarketData.asset_type == 'stock',
            MarketData.change_percent < 0,
            filter_condition
        ).order_by(asc(MarketData.change_percent)).limit(limit).all()
        result['losers'] = [l.to_dict() for l in losers]
    
    return jsonify(result)


@stocks_bp.route('/most-active', methods=['GET'])
def get_most_active():
    """Get most actively traded stocks"""
    limit = min(int(request.args.get('limit', 10)), 50)
    
    header_country = request.headers.get('X-User-Country')
    if header_country is None:
        filter_condition = (MarketData.country_code == 'US')
    else:
        country = header_country.strip().upper()
        filter_condition = (MarketData.country_code == 'GLOBAL') if country == 'GLOBAL' else (MarketData.country_code == country)

    stocks = MarketData.query.filter(
        MarketData.asset_type == 'stock',
        MarketData.volume != None,
        filter_condition
    ).order_by(desc(MarketData.volume)).limit(limit).all()
    
    return jsonify([{
        'symbol': s.symbol,
        'name': s.name,
        'price': float(s.price) if s.price else None,
        'volume': s.volume
    } for s in stocks])
