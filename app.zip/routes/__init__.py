"""
Routes package initialization
"""
from .auth import auth_bp
from .stocks import stocks_bp
from .crypto import crypto_bp
from .news import news_bp
from .geo import geo_bp
from .market import market_bp
from .portfolio import portfolio_bp
from .articles import articles_bp
from .content import content_bp
from .account import account_bp
from .user import user_bp
from .verification import verification_bp
from .devices import devices_bp
from .tools import tools_bp

__all__ = [
    'auth_bp', 
    'stocks_bp', 
    'crypto_bp', 
    'news_bp', 
    'geo_bp',
    'market_bp',
    'portfolio_bp',
    'articles_bp',
    'content_bp',
    'account_bp',
    'user_bp',
    'verification_bp',
    'devices_bp',
    'tools_bp'
]


